require 'test_helper'

class DownloadsHelperTest < ActionView::TestCase
end
