require 'test_helper'

class AgebTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
