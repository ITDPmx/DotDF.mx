##
#  Radius controller
#
class RadiusController < ApplicationController
  
  ##
  #  Replies with a JSON content depending on the selected radius (500,800, 1000, 2000)
  #
  def index
  end
end
