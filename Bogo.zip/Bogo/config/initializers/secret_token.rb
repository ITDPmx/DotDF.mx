# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Bogo::Application.config.secret_key_base = '1269a8b2f335b9c19dc74113f28a43164fb1b6925eee323ef4b1ef50e3ea7147348e36c11a2ae0cc2901ffd233e3dd73f9069e2ce93af8feac4fd7fe7bf453f7'
