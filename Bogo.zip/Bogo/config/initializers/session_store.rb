# Be sure to restart your server when you modify this file.

Bogo::Application.config.session_store :cookie_store, key: '_bogo_session'
